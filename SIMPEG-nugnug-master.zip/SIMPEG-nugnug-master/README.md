# SIMPEG-nugnug
just problem solver : Sistem Informasi Kepegawaian (SIMPEG) Kepegawaian Jln. Kebang Gula no 20, Manado
